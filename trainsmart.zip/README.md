This is the development of the FPDNG project phase 2
