<?php
/**
 * This code isn't actually used.
 * But it contains phrases that may need to be translated, such as the phrases from the country settings page.
 * These phrases are picked up and cataloged by the POEdit tool.
 */

//HAITI
t("Department");
t("City");
t("Training Name");
t("Training Organizer");
t("Training Level");
t('Level');
t('Organizer');
t("PEPFAR topic");
t("Training of Trainers");
t("Course Objectives");
t("Pre Test Score");
t("Post Test Score");
t("Course Objectives");
t("Custom field 1");
t("Custom field 2");
t("Custom field 3");
t("Custom field 4");
t("Custom field 5");
t("National ID");
t("Is Active");
t("First Name");
t("Middle Name");
t("Last Name");
t("English");
t("French");
t("Dutch");
t("Russian");
t("Ukranian");
t('Remove');
// javascript
t('Deleting...');
t('Are you sure you want to remove');
t('Undeleting...');
t('Saving...');
t('Edit');
t('Delete');
t('Are you sure you want to delete');
t('Pick a Date');
t('No records found.');
t('Loading...');
t('You have not selected a training category for your new title.');
t('Do you still wish to add a title without a training category associated with it?');
//itech.js
t('If you have made any changes to this page without clicking the Save button, your changes will be lost.  Are you sure you wish to leave this page?');
?>