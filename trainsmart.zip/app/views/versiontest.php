<?php
 echo phpinfo();
 echo 'over WinExp';
 echo 'over filezilla';
 

?>