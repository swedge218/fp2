<?php
/*
 * Created on Feb 14, 2008
 *
 *  Built for web
 *  Fuse IQ -- todd@fuseiq.com
 *
 */

require_once('ITechTable.php');


class File extends ITechTable
{
  protected $_name = 'file';
	protected $_primary = 'id';

}
