<?php
/*
 * Created on Oct 22, 2010
 *
 *  Built for web
 *  Fuse IQ -- nick@fuseiq.com
 *
 */

require_once ('ITechTable.php');

class SyncFile extends ITechTable
{
	protected $_name = 'syncfile';
	protected $_primary = 'id';



	

}


