<?php
/*
 * Created on Oct 22, 2010
 *
 *  Built for web
 *  Fuse IQ -- nick@fuseiq.com
 *
 */

require_once ('ITechTable.php');

class SyncAlias extends ITechTable
{
	protected $_name = 'syncalias';
	protected $_primary = 'id';



	

}


