<?php
require_once ('FacilityController.php');

class SiteController extends FacilityController {

	public function indexAction() {
		$this->_redirect('site/search');
	}

	public function siteAddAction() {
	}

	public function siteEditAction() {
	}

	public function siteSearchAction() {
	}
}